# Estrela-guia

Criadores recebem uma versão nova do seu vídeo, pronta para publicar

## Métrica

Vídeos processados baixados por semana
