# Transformador de Vídeo Único com transcodificação real

## Objetivo
Evoluir a ferramenta atual para receber vídeos por arrastar e soltar, oferecer três intensidades de transformação e entregar um novo MP4 totalmente reencodado para reprodução e download.

## Implementação
- Modernizar a área de envio com drag-and-drop, validação de MP4 e tamanho, estados visuais claros e progresso separado de envio e processamento.
- Adicionar um seletor `Leve`, `Médio` e `Agressivo`, com uma descrição objetiva das mudanças de cada nível.
- Manter os arquivos originais e processados nos buckets privados já existentes, sempre dentro da pasta da conta autenticada.
- Substituir a alteração apenas de metadados por um pipeline FFmpeg real executado em um serviço de mídia dedicado. O app enviará uma URL temporária do original, o nível escolhido e uma URL temporária de destino; o serviço retornará o MP4 processado.
- Aplicar em uma única execução: espelhamento, zoom/corte conforme o nível, ajuste discreto de brilho/cor, velocidade e áudio proporcionais, 29,97 fps, áudio em 48 kHz, remoção de metadados e reencodamento H.264/AAC.
- Proteger a chamada ao serviço com um segredo compartilhado e validar usuário, caminho, tipo, tamanho e resultado antes de liberar o download.
- Exibir progresso de processamento por etapas, resultado em vídeo e botão de download.

## Serviço de mídia recomendado
Usar um pequeno serviço Docker com FFmpeg em Render, Railway, Fly.io ou AWS. Essa opção é mais confiável que FFmpeg/WASM dentro de uma função curta, especialmente para vídeos de até 100 MB, e permite controlar exatamente filtros, codecs e limites.

O projeto incluirá o código completo desse serviço e a integração do aplicativo. A implantação do serviço externo e a inclusão da URL/segredo serão a única etapa dependente da conta do provedor escolhido.

## Validação
- Verificar acesso privado e rejeição de caminhos fora da conta.
- Testar seleção, arrastar e soltar, os três níveis e estados de erro.
- Testar upload, processamento, reprodução e download com um MP4 real.
- Conferir a interface em celular e computador e confirmar que o aplicativo continua instalável.
