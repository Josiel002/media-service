# Autenticação privada e instalação no celular

## Resultado
- Criar uma tela simples de entrada com e-mail e senha, sem opção de cadastro.
- Restringir a ferramenta de vídeo e o processamento à conta `josielf1002@gmail.com`.
- Bloquear novos cadastros públicos no Lovable Cloud Auth.
- Adicionar manifesto e ícones para instalar o aplicativo na tela inicial, sem modo offline.

## Implementação
- Mover a ferramenta para uma área protegida e manter a entrada em uma página pública.
- Validar a sessão e o e-mail permitido tanto na navegação quanto no processamento interno.
- Restringir os arquivos enviados e processados à conta autorizada.
- Adicionar saída segura, limpando dados temporários antes de retornar à tela de entrada.
- Gerar ícones próprios e incluir os metadados de instalação.

## Validação
- Conferir entrada inválida, acesso sem sessão, saída da conta e fluxo completo de vídeo autenticado.
- Verificar a instalação e a apresentação em celular e computador.
