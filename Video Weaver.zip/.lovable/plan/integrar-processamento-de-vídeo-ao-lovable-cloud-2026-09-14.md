# Integrar processamento de vídeo ao Lovable Cloud

## Objetivo
Substituir a chamada à função da plataforma antiga por uma função interna do aplicativo, mantendo todo o fluxo no Lovable Cloud.

## Implementação
- Criar uma função de servidor que valide o caminho recebido, baixe o MP4 original do armazenamento privado, gere uma nova versão válida com metadados exclusivos e salve o resultado em `videos-processados`.
- Retornar um link temporário seguro para visualização e download do arquivo final.
- Atualizar a tela para chamar essa função interna e preservar os estados de espera, sucesso e erro.
- Validar o fluxo completo no navegador: upload real, processamento, reprodução e download.

## Detalhes técnicos
- A função será implementada com `createServerFn`, sem Edge Function antiga.
- O arquivo gerado continuará sendo um MP4 válido; sua estrutura recebe um bloco de metadados exclusivo sem alterar o conteúdo audiovisual.
- O processamento será limitado por tamanho e tipo para evitar uso indevido de memória.
