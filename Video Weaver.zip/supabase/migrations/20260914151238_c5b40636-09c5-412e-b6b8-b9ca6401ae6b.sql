DROP POLICY IF EXISTS "Public can upload original videos" ON storage.objects;

CREATE POLICY "Authorized user can upload original videos"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'videos-originais'
  AND lower(coalesce(auth.jwt() ->> 'email', '')) = 'josielf1002@gmail.com'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Authorized user can read original videos"
ON storage.objects
FOR SELECT
TO authenticated
USING (
  bucket_id = 'videos-originais'
  AND lower(coalesce(auth.jwt() ->> 'email', '')) = 'josielf1002@gmail.com'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Authorized user can create processed videos"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'videos-processados'
  AND lower(coalesce(auth.jwt() ->> 'email', '')) = 'josielf1002@gmail.com'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Authorized user can read processed videos"
ON storage.objects
FOR SELECT
TO authenticated
USING (
  bucket_id = 'videos-processados'
  AND lower(coalesce(auth.jwt() ->> 'email', '')) = 'josielf1002@gmail.com'
  AND (storage.foldername(name))[1] = auth.uid()::text
);