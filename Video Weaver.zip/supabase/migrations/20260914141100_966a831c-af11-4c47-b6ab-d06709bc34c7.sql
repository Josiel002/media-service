CREATE POLICY "Public can upload original videos"
ON storage.objects
FOR INSERT
TO anon
WITH CHECK (bucket_id = 'videos-originais');