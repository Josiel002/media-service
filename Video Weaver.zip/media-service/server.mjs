import { createReadStream, createWriteStream } from "node:fs";
import { mkdir, rm, stat } from "node:fs/promises";
import { pipeline } from "node:stream/promises";
import { Readable } from "node:stream";
import { spawn } from "node:child_process";
import { createHash, randomUUID, timingSafeEqual } from "node:crypto";
import express from "express";
import { z } from "zod";

const app = express();
const port = Number(process.env.PORT ?? 8080);
const maxBytes = 100 * 1024 * 1024;

app.use(express.json({ limit: "32kb" }));

const requestSchema = z.object({
  inputUrl: z.string().url(),
  outputUrl: z.string().url(),
  level: z.enum(["light", "medium", "aggressive"]),
});

const presets = {
  light: { zoomMin: 1.03, zoomMax: 1.04, speed: 1.02, brightness: 0.015, saturation: 1.02, videoBitrate: "4200k" },
  medium: { zoomMin: 1.04, zoomMax: 1.05, speed: 1.035, brightness: 0.025, saturation: 1.04, videoBitrate: "3600k" },
  aggressive: { zoomMin: 1.05, zoomMax: 1.06, speed: 1.05, brightness: 0.035, saturation: 1.06, videoBitrate: "3000k" },
};

function authorized(header) {
  const secret = process.env.MEDIA_SERVICE_SECRET;
  if (!secret || !header?.startsWith("Bearer ")) return false;
  const supplied = Buffer.from(header.slice(7));
  const expected = Buffer.from(secret);
  return supplied.length === expected.length && timingSafeEqual(supplied, expected);
}

function runFfmpeg(input, output, preset) {
  const zoom = (preset.zoomMin + Math.random() * (preset.zoomMax - preset.zoomMin)).toFixed(4);
  const videoFilter = [
    "hflip",
    `scale=trunc(iw*${zoom}/2)*2:trunc(ih*${zoom}/2)*2`,
    `crop=trunc(iw/${zoom}/2)*2:trunc(ih/${zoom}/2)*2`,
    `eq=brightness=${preset.brightness}:saturation=${preset.saturation}`,
    `setpts=PTS/${preset.speed}`,
    "fps=30000/1001",
  ].join(",");
  const audioFilter = `atempo=${preset.speed},aresample=48000`;
  const args = [
    "-hide_banner", "-loglevel", "error", "-y", "-i", input,
    "-map", "0:v:0", "-map", "0:a?", "-map_metadata", "-1", "-map_chapters", "-1",
    "-vf", videoFilter, "-af", audioFilter,
    "-c:v", "libx264", "-preset", "medium", "-profile:v", "high",
    "-pix_fmt", "yuv420p", "-b:v", preset.videoBitrate, "-maxrate", preset.videoBitrate,
    "-bufsize", "7200k", "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
    "-movflags", "+faststart", output,
  ];
  return new Promise((resolve, reject) => {
    const child = spawn("ffmpeg", args, { stdio: ["ignore", "ignore", "pipe"] });
    let stderr = "";
    child.stderr.on("data", (chunk) => { stderr += chunk.toString().slice(0, 2000); });
    child.once("error", reject);
    child.once("close", (code) => code === 0 ? resolve() : reject(new Error(stderr || `FFmpeg exited with ${code}`)));
  });
}

async function sha256(path) {
  const hash = createHash("sha256");
  for await (const chunk of createReadStream(path)) hash.update(chunk);
  return hash.digest("hex");
}

app.get("/health", (_request, response) => response.json({ ok: true }));

app.post("/process", async (request, response) => {
  if (!authorized(request.headers.authorization)) return response.status(401).json({ error: "Unauthorized" });
  const parsed = requestSchema.safeParse(request.body);
  if (!parsed.success) return response.status(400).json({ error: "Invalid request" });

  const workdir = `/tmp/video-${randomUUID()}`;
  const input = `${workdir}/input.mp4`;
  const output = `${workdir}/output.mp4`;
  try {
    await mkdir(workdir, { recursive: true });
    const source = await fetch(parsed.data.inputUrl);
    const length = Number(source.headers.get("content-length") ?? 0);
    if (!source.ok || !source.body) throw new Error("Original video download failed");
    if (length > maxBytes) return response.status(413).json({ error: "Video too large" });
    await pipeline(Readable.fromWeb(source.body), createWriteStream(input));
    if ((await stat(input)).size > maxBytes) return response.status(413).json({ error: "Video too large" });

    await runFfmpeg(input, output, presets[parsed.data.level]);
    const upload = await fetch(parsed.data.outputUrl, {
      method: "PUT",
      headers: { "content-type": "video/mp4", "x-upsert": "false" },
      body: createReadStream(output),
      duplex: "half",
    });
    if (!upload.ok) throw new Error(`Processed video upload failed (${upload.status})`);
    return response.json({
      ok: true,
      bytes: (await stat(output)).size,
      sha256: await sha256(output),
    });
  } catch (error) {
    console.error("Processing failed", error);
    return response.status(500).json({ error: "Processing failed" });
  } finally {
    await rm(workdir, { recursive: true, force: true });
  }
});

app.listen(port, "0.0.0.0", () => console.log(`Media service listening on ${port}`));
