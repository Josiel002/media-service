# Serviço FFmpeg

Serviço Docker usado pelo aplicativo para reencodar vídeos. A opção recomendada é o Render, usando o `Dockerfile` e o `render.yaml` desta pasta. Railway, Fly.io ou AWS também funcionam.

## Configuração

Defina `MEDIA_SERVICE_SECRET` com o mesmo valor salvo nos segredos do aplicativo. O serviço expõe:

- `GET /health`
- `POST /process` (protegido por `Authorization: Bearer ...`)

Depois da implantação, salve no aplicativo:

- `MEDIA_SERVICE_URL`: URL HTTPS do serviço, sem barra final.
- `MEDIA_SERVICE_SECRET`: segredo forte compartilhado com o serviço.

O aplicativo cria links temporários de leitura e gravação para os buckets privados. O serviço baixa o original, executa FFmpeg em uma passagem e grava o resultado diretamente no armazenamento, sem receber credenciais permanentes.

## Conexão com o armazenamento

1. O navegador envia o MP4 para `videos-originais/<id-da-conta>/...` usando a sessão autenticada.
2. A função interna valida conta, e-mail, caminho, cabeçalho MP4 e limite de 100 MB.
3. A função cria uma URL de leitura temporária do original e uma URL de gravação temporária para `videos-processados`.
4. O serviço recebe somente essas URLs temporárias e o nível escolhido; nenhuma chave permanente do armazenamento sai do aplicativo.
5. O FFmpeg espelha, aplica zoom/corte, ajusta cor, velocidade, áudio, framerate e remove os metadados durante o reencodamento H.264/AAC.
6. O serviço calcula o novo SHA-256, envia o MP4 final pela URL temporária e confirma a conclusão.
7. A função verifica a existência do resultado e devolve ao navegador um link de download válido por uma hora.

## Implantação no Render

1. Publique o repositório em um provedor Git compatível com o Render.
2. No Render, crie um Blueprint apontando a pasta `media-service` e seu `render.yaml`.
3. Gere um segredo forte e configure-o como `MEDIA_SERVICE_SECRET` no serviço.
4. Copie a URL HTTPS criada pelo Render.
5. Salve no aplicativo a URL em `MEDIA_SERVICE_URL` e o mesmo segredo em `MEDIA_SERVICE_SECRET`.
6. Publique novamente o aplicativo e teste um vídeo curto antes de usar arquivos maiores.
