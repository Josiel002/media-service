import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";

import { supabase } from "@/integrations/supabase/client";

const OWNER_EMAIL = "josielf1002@gmail.com";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    if (
      error ||
      !data.user ||
      data.user.email?.toLowerCase() !== OWNER_EMAIL
    ) {
      if (data.user) await supabase.auth.signOut();
      throw redirect({ to: "/" });
    }
    return { user: data.user };
  },
  component: () => <Outlet />,
});