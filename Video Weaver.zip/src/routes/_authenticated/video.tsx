import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState, type DragEvent } from "react";
import {
  UploadCloud,
  Loader2,
  Download,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  Film,
  LogOut,
  Gauge,
} from "lucide-react";
import {
  BUCKET_ORIGINAL,
} from "@/lib/supabase-client";
import { processVideo } from "@/lib/video.functions";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";

const TITLE = "Reprocessador Anti-Algoritmo de Vídeos";
const DESCRIPTION =
  "Envie seu vídeo .mp4 e transforme-o em uma versão única, reprocessada para escapar da detecção de conteúdo repetido.";

export const Route = createFileRoute("/_authenticated/video")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

type Stage = "idle" | "uploading" | "uploaded" | "processing" | "done";
type Level = "light" | "medium" | "aggressive";

const LEVELS: Array<{ value: Level; label: string; detail: string }> = [
  { value: "light", label: "Leve", detail: "Mudanças discretas" },
  { value: "medium", label: "Médio", detail: "Equilíbrio ideal" },
  { value: "aggressive", label: "Agressivo", detail: "Alteração máxima" },
];

function Index() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { user } = Route.useRouteContext();
  const processVideoFn = useServerFn(processVideo);
  const inputRef = useRef<HTMLInputElement>(null);
  const [stage, setStage] = useState<Stage>("idle");
  const [file, setFile] = useState<File | null>(null);
  const [originalPath, setOriginalPath] = useState<string | null>(null);
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [level, setLevel] = useState<Level>("medium");
  const [dragging, setDragging] = useState(false);

  const busy = stage === "uploading" || stage === "processing";

  useEffect(() => {
    if (stage !== "uploading" && stage !== "processing") return;
    setProgress(stage === "uploading" ? 10 : 12);
    const ceiling = stage === "uploading" ? 88 : 92;
    const timer = window.setInterval(() => {
      setProgress((value) => Math.min(ceiling, value + Math.max(1, Math.round((ceiling - value) / 7))));
    }, 1200);
    return () => window.clearInterval(timer);
  }, [stage]);

  async function handleFile(selected: File | undefined) {
    if (!selected) return;
    setError(null);
    setResultUrl(null);
    setOriginalPath(null);

    if (!selected.name.toLowerCase().endsWith(".mp4")) {
      setError("Escolha um arquivo no formato .mp4.");
      return;
    }

    if (selected.size > 100 * 1024 * 1024) {
      setError("O vídeo deve ter no máximo 100 MB.");
      return;
    }

    setFile(selected);
    setStage("uploading");
    setProgress(10);

    const safeName = selected.name.replace(/[^a-zA-Z0-9.\-_]/g, "_");
    const path = `${user.id}/${crypto.randomUUID()}-${safeName}`;
    const { error: uploadError } = await supabase.storage
      .from(BUCKET_ORIGINAL)
      .upload(path, selected, { contentType: "video/mp4", upsert: false });

    if (uploadError) {
      setStage("idle");
      setProgress(0);
      setError(`Não foi possível enviar o vídeo: ${uploadError.message}`);
      return;
    }

    setOriginalPath(path);
    setProgress(100);
    setStage("uploaded");
  }

  function handleDrop(event: DragEvent<HTMLButtonElement>) {
    event.preventDefault();
    setDragging(false);
    if (!busy) void handleFile(event.dataTransfer.files[0]);
  }

  async function handleProcess() {
    if (!originalPath) return;

    setError(null);
    setStage("processing");
    setResultUrl(null);

    try {
      const result = await processVideoFn({ data: { path: originalPath, level } });
      if (!result.ok) {
        setStage("uploaded");
        setError(result.error);
        return;
      }

      setResultUrl(result.url);
      setProgress(100);
      setStage("done");
    } catch (processError) {
      setStage("uploaded");
      console.error(processError);
      setError("O processamento falhou. Tente novamente em instantes.");
    }
  }

  function reset() {
    setStage("idle");
    setFile(null);
    setOriginalPath(null);
    setResultUrl(null);
    setProgress(0);
    setError(null);
    if (inputRef.current) inputRef.current.value = "";
  }

  async function handleSignOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    await navigate({ to: "/", replace: true });
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-hero">
      <div className="pointer-events-none absolute inset-0 grid-noise" />

      <div className="relative mx-auto w-full max-w-4xl px-5 py-10 sm:py-16">
        <header className="relative text-center">
          <Button type="button" variant="ghost" size="icon" className="absolute right-0 top-0" onClick={() => void handleSignOut()} aria-label="Sair">
            <LogOut className="size-5" />
          </Button>
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-3 py-1 text-xs font-medium tracking-wide text-muted-foreground uppercase">
            <Sparkles className="size-3.5 text-primary" />
            Anti-algoritmo
          </span>
          <h1 className="mt-5 text-4xl leading-tight font-bold text-foreground sm:text-5xl">
            Transformador de Vídeo{" "}
            <span className="bg-accent-gradient bg-clip-text text-transparent">
              Único
            </span>
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-sm text-muted-foreground sm:text-base">
            {DESCRIPTION}
          </p>
        </header>

        <section className="mt-10 border border-border bg-card/70 p-5 shadow-panel backdrop-blur sm:p-8">
          <Button
            type="button"
            variant="outline"
            onClick={() => !busy && inputRef.current?.click()}
            onDragEnter={(event) => { event.preventDefault(); setDragging(true); }}
            onDragOver={(event) => event.preventDefault()}
            onDragLeave={() => setDragging(false)}
            onDrop={handleDrop}
            disabled={busy}
            className={`group h-auto min-h-52 w-full flex-col gap-3 border-2 border-dashed px-6 py-10 text-center transition-colors ${dragging ? "border-primary bg-primary/10" : "border-border bg-secondary/20 hover:border-primary/60 hover:bg-secondary/40"}`}
          >
            <span className="flex size-14 items-center justify-center rounded-full bg-primary/10">
              <UploadCloud className="size-7 text-primary" />
            </span>
            <span className="text-base font-semibold text-foreground">
              {file ? file.name : "Arraste seu vídeo para cá"}
            </span>
            <span className="text-xs text-muted-foreground">
              {file
                ? `${(file.size / (1024 * 1024)).toFixed(1)} MB`
                : "ou clique para selecionar um MP4 de até 100 MB"}
            </span>
          </Button>
          <input
            ref={inputRef}
            type="file"
            accept="video/mp4,.mp4"
            className="hidden"
            onChange={(e) => void handleFile(e.target.files?.[0])}
          />

          {(stage === "uploading" || stage === "uploaded" || stage === "processing") && (
            <div className="mt-5" aria-live="polite">
              <Progress value={progress} />
              <p className="mt-2 flex items-center justify-between gap-2 text-xs text-muted-foreground">
                <span className="flex items-center gap-2">
                {stage === "uploading" ? (
                  <>
                    <Loader2 className="size-3.5 animate-spin" />
                    Enviando vídeo...
                  </>
                ) : stage === "processing" ? (
                  <><Loader2 className="size-3.5 animate-spin" /> Processando em alta qualidade...</>
                ) : (
                  <>
                    <CheckCircle2 className="size-3.5 text-primary" />
                    Vídeo enviado com sucesso.
                  </>
                )}
                </span>
                <span>{progress}%</span>
              </p>
            </div>
          )}

          <div className="mt-7">
            <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-foreground">
              <Gauge className="size-4 text-accent" />
              Nível de transformação
            </div>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-3" role="radiogroup" aria-label="Nível de transformação">
              {LEVELS.map((option) => (
                <Button
                  key={option.value}
                  type="button"
                  variant={level === option.value ? "default" : "outline"}
                  className="h-auto min-h-16 flex-col gap-0.5"
                  disabled={busy}
                  aria-pressed={level === option.value}
                  onClick={() => setLevel(option.value)}
                >
                  <span>{option.label}</span>
                  <span className={`text-xs font-normal ${level === option.value ? "text-primary-foreground/75" : "text-muted-foreground"}`}>{option.detail}</span>
                </Button>
              ))}
            </div>
          </div>

          <Button
            size="lg"
            className="mt-6 h-12 w-full rounded-xl text-base font-semibold shadow-glow"
            disabled={stage !== "uploaded" || busy}
            onClick={() => void handleProcess()}
          >
            {stage === "processing" ? (
              <>
                <Loader2 className="size-5 animate-spin" />
                Processando...
              </>
            ) : (
              <>
                <Sparkles className="size-5" />
                Transformar em Vídeo Único
              </>
            )}
          </Button>

          {stage === "processing" && (
            <div className="mt-6 flex flex-col items-center gap-3 border border-border bg-secondary/40 px-5 py-8 text-center">
              <Loader2 className="size-8 animate-spin text-primary" />
              <p className="text-sm font-medium text-foreground">
                Reprocessando seu vídeo
              </p>
              <p className="text-xs text-muted-foreground">
                Isso pode levar alguns minutos. Mantenha esta tela aberta.
              </p>
            </div>
          )}

          {stage === "done" && resultUrl && (
            <div className="mt-6 space-y-4">
              <div className="flex items-center gap-2 text-sm font-medium text-primary">
                <CheckCircle2 className="size-4" />
                Vídeo único pronto
              </div>
              <video
                src={resultUrl}
                controls
                playsInline
                className="aspect-video w-full border border-border bg-background object-contain"
              />
              <div className="flex flex-col gap-3 sm:flex-row">
                <Button asChild size="lg" className="h-12 flex-1 rounded-xl">
                  <a href={resultUrl} download target="_blank" rel="noreferrer">
                    <Download className="size-5" />
                    Baixar vídeo final
                  </a>
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="h-12 rounded-xl"
                  onClick={reset}
                >
                  <Film className="size-5" />
                  Novo vídeo
                </Button>
              </div>
            </div>
          )}

          {error && (
            <p className="mt-5 flex items-start gap-2 rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-foreground">
              <AlertTriangle className="mt-0.5 size-4 shrink-0 text-destructive" />
              {error}
            </p>
          )}
        </section>
      </div>
    </main>
  );
}
