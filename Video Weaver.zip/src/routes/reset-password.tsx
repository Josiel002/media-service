import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Loader2, LockKeyhole } from "lucide-react";
import { FormEvent, useEffect, useState } from "react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Nova senha | Vídeo Único" },
      { name: "description", content: "Defina uma nova senha para o Vídeo Único." },
      { property: "og:title", content: "Nova senha | Vídeo Único" },
      { property: "og:description", content: "Defina uma nova senha para o Vídeo Único." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [hasRecoverySession, setHasRecoverySession] = useState(false);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const hash = new URLSearchParams(window.location.hash.slice(1));
    const isRecovery = hash.get("type") === "recovery" || hash.get("type") === "invite";
    void supabase.auth.getSession().then(({ data }) => {
      setHasRecoverySession(isRecovery || Boolean(data.session));
      setBusy(false);
    });
  }, []);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    if (password.length < 8) {
      setError("Use pelo menos 8 caracteres.");
      return;
    }
    if (password !== confirmPassword) {
      setError("As senhas não coincidem.");
      return;
    }
    setBusy(true);
    const { error: updateError } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (updateError) {
      setError("O link expirou ou não é válido. Solicite um novo link.");
      return;
    }
    await navigate({ to: "/video", replace: true });
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-hero px-5 py-10">
      <section className="w-full max-w-sm rounded-2xl border border-border bg-card/80 p-6 shadow-panel">
        <LockKeyhole className="size-8 text-primary" />
        <h1 className="mt-4 text-2xl font-bold text-foreground">Crie sua nova senha</h1>
        <p className="mt-2 text-sm text-muted-foreground">Use uma senha segura com pelo menos 8 caracteres.</p>
        {!busy && !hasRecoverySession ? (
          <div className="mt-6 space-y-4">
            <p className="text-sm text-destructive">Este link expirou ou não é válido.</p>
            <Button className="w-full" onClick={() => void navigate({ to: "/" })}>Voltar para entrar</Button>
          </div>
        ) : (
          <form className="mt-6 space-y-4" onSubmit={handleSubmit}>
            <div className="space-y-2"><Label htmlFor="new-password">Nova senha</Label><Input id="new-password" type="password" autoComplete="new-password" value={password} onChange={(event) => setPassword(event.target.value)} required /></div>
            <div className="space-y-2"><Label htmlFor="confirm-password">Repita a senha</Label><Input id="confirm-password" type="password" autoComplete="new-password" value={confirmPassword} onChange={(event) => setConfirmPassword(event.target.value)} required /></div>
            {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
            <Button type="submit" size="lg" className="w-full" disabled={busy}>{busy && <Loader2 className="size-4 animate-spin" />}Salvar senha</Button>
          </form>
        )}
      </section>
    </main>
  );
}