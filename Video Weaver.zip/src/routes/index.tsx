import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Eye, EyeOff, Loader2, LockKeyhole, Mail } from "lucide-react";
import { FormEvent, useEffect, useState } from "react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { requestOwnerAccess } from "@/lib/auth.functions";

const OWNER_EMAIL = "josielf1002@gmail.com";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Entrar | Vídeo Único" },
      { name: "description", content: "Acesso privado à ferramenta Vídeo Único." },
      { property: "og:title", content: "Entrar | Vídeo Único" },
      { property: "og:description", content: "Acesso privado à ferramenta Vídeo Único." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const requestAccess = useServerFn(requestOwnerAccess);
  const [email, setEmail] = useState(OWNER_EMAIL);
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    void supabase.auth.getUser().then(({ data }) => {
      if (data.user?.email?.toLowerCase() === OWNER_EMAIL) {
        void navigate({ to: "/video", replace: true });
      }
    });
  }, [navigate]);

  async function handleLogin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);
    setMessage(null);
    if (email.trim().toLowerCase() !== OWNER_EMAIL) {
      setError("Este e-mail não tem acesso à ferramenta.");
      return;
    }
    setBusy(true);
    const { data, error: signInError } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });
    setBusy(false);
    if (signInError || data.user?.email?.toLowerCase() !== OWNER_EMAIL) {
      if (data.user) await supabase.auth.signOut();
      setError("E-mail ou senha incorretos.");
      return;
    }
    await navigate({ to: "/video", replace: true });
  }

  async function handleFirstAccess() {
    setBusy(true);
    setError(null);
    await requestAccess({ data: { origin: window.location.origin } });
    setBusy(false);
    setMessage("Se a conta ainda não existia, enviamos um link para criar sua senha.");
  }

  async function handleReset() {
    setBusy(true);
    setError(null);
    const { error: resetError } = await supabase.auth.resetPasswordForEmail(
      OWNER_EMAIL,
      { redirectTo: `${window.location.origin}/reset-password` },
    );
    setBusy(false);
    if (resetError) {
      setError("Não foi possível enviar o link agora. Tente novamente em instantes.");
      return;
    }
    setMessage("Enviamos as instruções de recuperação para o e-mail autorizado.");
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-hero px-5 py-10">
      <section className="w-full max-w-sm" aria-labelledby="login-title">
        <div className="mb-8 text-center">
          <div className="mx-auto flex size-12 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-glow">
            <LockKeyhole className="size-6" />
          </div>
          <h1 id="login-title" className="mt-5 text-3xl font-bold text-foreground">Vídeo Único</h1>
          <p className="mt-2 text-sm text-muted-foreground">Entre para acessar sua ferramenta privada.</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-5 rounded-2xl border border-border bg-card/80 p-6 shadow-panel">
          <div className="space-y-2">
            <Label htmlFor="email">E-mail</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input id="email" type="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} className="pl-10" required />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Senha</Label>
            <div className="relative">
              <Input id="password" type={showPassword ? "text" : "password"} autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} className="pr-11" required />
              <Button type="button" variant="ghost" size="icon" className="absolute right-0 top-0" onClick={() => setShowPassword((value) => !value)} aria-label={showPassword ? "Ocultar senha" : "Mostrar senha"}>
                {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
              </Button>
            </div>
          </div>
          {error && <p role="alert" className="text-sm text-destructive">{error}</p>}
          {message && <p role="status" className="text-sm text-primary">{message}</p>}
          <Button type="submit" size="lg" className="w-full" disabled={busy}>
            {busy && <Loader2 className="size-4 animate-spin" />}
            Entrar
          </Button>
          <div className="flex items-center justify-between gap-3 text-xs">
            <Button type="button" variant="link" className="h-auto p-0 text-muted-foreground" onClick={handleFirstAccess} disabled={busy}>Primeiro acesso</Button>
            <Button type="button" variant="link" className="h-auto p-0 text-muted-foreground" onClick={handleReset} disabled={busy}>Esqueci minha senha</Button>
          </div>
        </form>
      </section>
    </main>
  );
}