import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

import {
  BUCKET_ORIGINAL,
  BUCKET_PROCESSED,
} from "@/lib/supabase-client";

const MAX_VIDEO_BYTES = 100 * 1024 * 1024;
const ORIGINAL_PATH = /^[0-9a-f-]{36}\/[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}-[A-Za-z0-9._-]+\.mp4$/i;
const OWNER_EMAIL = "josielf1002@gmail.com";

const processVideoInput = z.object({
  path: z.string().min(42).max(240).regex(ORIGINAL_PATH),
  level: z.enum(["light", "medium", "aggressive"]),
});

function isMp4(bytes: Uint8Array): boolean {
  if (bytes.length < 12) return false;
  return new TextDecoder().decode(bytes.slice(4, 8)) === "ftyp";
}

export const processVideo = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => processVideoInput.parse(input))
  .handler(async ({ data, context }) => {
    if (
      context.claims.email?.toString().toLowerCase() !== OWNER_EMAIL ||
      !data.path.startsWith(`${context.userId}/`)
    ) {
      return { ok: false as const, error: "Acesso não autorizado." };
    }
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );

    const originalName = data.path.slice(data.path.lastIndexOf("/") + 1);
    const { data: originals, error: originalError } = await supabaseAdmin.storage
      .from(BUCKET_ORIGINAL)
      .list(context.userId, { search: originalName, limit: 1 });
    const originalInfo = originals?.find((item) => item.name === originalName);
    if (originalError || !originalInfo) {
      return { ok: false as const, error: "O vídeo original não foi encontrado." };
    }

    const originalSize = Number(originalInfo.metadata?.size ?? 0);
    if (originalSize === 0 || originalSize > MAX_VIDEO_BYTES) {
      return {
        ok: false as const,
        error: "O vídeo deve ter no máximo 100 MB.",
      };
    }

    const serviceUrl = process.env['MEDIA_SERVICE_URL']?.replace(/\/$/, "");
    const serviceSecret = process.env['MEDIA_SERVICE_SECRET'];
    if (!serviceUrl || !serviceSecret) {
      return {
        ok: false as const,
        error: "O serviço de processamento ainda precisa ser conectado.",
      };
    }

    const outputPath = `${context.userId}/processado-${crypto.randomUUID()}.mp4`;
    const [{ data: source }, { data: destination, error: destinationError }] = await Promise.all([
      supabaseAdmin.storage.from(BUCKET_ORIGINAL).createSignedUrl(data.path, 15 * 60),
      supabaseAdmin.storage.from(BUCKET_PROCESSED).createSignedUploadUrl(outputPath),
    ]);
    if (!source?.signedUrl || destinationError || !destination?.signedUrl) {
      console.error("Failed to create temporary media URLs", destinationError);
      return { ok: false as const, error: "Não foi possível preparar o processamento." };
    }

    const headerResponse = await fetch(source.signedUrl, { headers: { range: "bytes=0-11" } });
    const header = new Uint8Array(await headerResponse.arrayBuffer());
    if (!headerResponse.ok || !isMp4(header)) {
      return { ok: false as const, error: "O arquivo enviado não é um MP4 válido." };
    }

    let mediaResponse: Response;
    try {
      mediaResponse = await fetch(`${serviceUrl}/process`, {
        method: "POST",
        headers: {
          "authorization": `Bearer ${serviceSecret}`,
          "content-type": "application/json",
        },
        body: JSON.stringify({
          inputUrl: source.signedUrl,
          outputUrl: destination.signedUrl,
          level: data.level,
        }),
        signal: AbortSignal.timeout(10 * 60 * 1000),
      });
    } catch (error) {
      console.error("Media service request failed", error);
      return { ok: false as const, error: "O serviço de vídeo não respondeu a tempo." };
    }
    if (!mediaResponse.ok) {
      console.error("Media service rejected processing", mediaResponse.status);
      return { ok: false as const, error: "Não foi possível transformar o vídeo." };
    }

    const outputName = outputPath.slice(outputPath.lastIndexOf("/") + 1);
    const { data: processedInfo, error: processedError } = await supabaseAdmin.storage
      .from(BUCKET_PROCESSED)
      .list(context.userId, { search: outputName, limit: 1 });
    if (processedError || !processedInfo?.length) {
      return { ok: false as const, error: "O arquivo processado não foi confirmado." };
    }

    const { data: signed, error: signedError } = await supabaseAdmin.storage
      .from(BUCKET_PROCESSED)
      .createSignedUrl(outputPath, 60 * 60, {
        download: `video-unico-${Date.now()}.mp4`,
      });

    if (signedError || !signed?.signedUrl) {
      console.error("Failed to sign processed video URL", signedError);
      return {
        ok: false as const,
        error: "O vídeo foi processado, mas o link não pôde ser criado.",
      };
    }

    return {
      ok: true as const,
      outputPath,
      url: signed.signedUrl,
    };
  });