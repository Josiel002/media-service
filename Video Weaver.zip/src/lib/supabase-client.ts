export const BUCKET_ORIGINAL = "videos-originais";
export const BUCKET_PROCESSED = "videos-processados";
