import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const OWNER_EMAIL = "josielf1002@gmail.com";

export const requestOwnerAccess = createServerFn({ method: "POST" })
  .inputValidator((input) => z.object({ origin: z.string().url() }).parse(input))
  .handler(async ({ data: input }) => {
    const origin = new URL(input.origin);
    const allowedOrigin = origin.hostname === "localhost" || origin.hostname.endsWith(".lovable.app");
    if (!allowedOrigin) return { ok: true as const };
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );

    const { data } = await supabaseAdmin.auth.admin.listUsers({
      page: 1,
      perPage: 100,
    });
    const ownerExists = data.users.some(
      (user) => user.email?.toLowerCase() === OWNER_EMAIL,
    );

    if (!ownerExists) {
      const { error } = await supabaseAdmin.auth.admin.inviteUserByEmail(
        OWNER_EMAIL,
        { redirectTo: `${origin.origin}/reset-password` },
      );
      if (error) {
        console.error("Failed to invite authorized owner", error);
      }
    }

    return { ok: true as const };
  });